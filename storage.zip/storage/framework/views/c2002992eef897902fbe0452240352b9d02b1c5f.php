<?php $__env->startSection('head'); ?>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <meta name="description" content="Logisti ">
  <title><?php echo $project->name; ?> -Project | PZI </title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700%7cWork+Sans:400,600,700&display=swap">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/libraries.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

    <!-- ========================
       page title 
    =========================== -->
    <section id="page-title" class="page-title bg-overlay bg-parallax">
      <div class="bg-img"><img src="<?php echo e(asset('img/banner1.jpg')); ?>" alt="<?php echo e(config('app.name')); ?>"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">News & Media</li>
              </ol>
            </nav>
            <h1 class="pagetitle__heading">News & Media</h1>
          </div><!-- /.col-lg-12 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.page-title -->

    <!-- ======================
      Blog Single
    ========================= -->
    <section id="blogSingleCentered" class="blog blog-single pb-60">
      <div class="container">
        <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
          
          <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="blog-item">
              <div class="blog__img">
                <a href="#">
                  <img src="<?php echo postImage($project->image); ?>" alt="<?php echo $project->name; ?>">
                </a>
              </div><!-- /.entry-img -->
              <div class="blog__content">
                <h4 class="blog__title"><a href="#"><?php echo $project->name; ?></a></h4>
                <div class="blog__meta justify-content-center">
                  <span class="blog__meta-author pr-20">By: <span>Admin</span></span>
                  <span class="blog__meta-date"><?php echo $project->created_at->format('M d, Y'); ?></span>
                </div><!-- /.blog-meta -->
                <div class="divider__line divider__theme divider__center"></div>
                <div class="blog__desc">
                  <p><?php echo $project->details; ?></p>
                </div><!-- /.blog-desc -->
              </div><!-- /.entry-content -->
            </div><!-- /.blog-item -->
            

          </div><!-- /.col-lg-8 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.blog Single -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

  <script src="<?php echo e(asset('assets/js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\logistics\resources\views/projects-single.blade.php ENDPATH**/ ?>