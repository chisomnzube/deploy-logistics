<?php $__env->startSection('head'); ?>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <meta name="description" content="Logisti ">
  <title><?php echo $post->title; ?> - PZI </title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700%7cWork+Sans:400,600,700&display=swap">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/libraries.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

    <!-- ========================
       page title 
    =========================== -->
    <section id="page-title" class="page-title bg-overlay bg-parallax">
      <div class="bg-img"><img src="<?php echo e(asset('img/banner1.jpg')); ?>" alt="<?php echo e(config('app.name')); ?>"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">News & Media</li>
              </ol>
            </nav>
            <h1 class="pagetitle__heading">News & Media</h1>
          </div><!-- /.col-lg-12 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.page-title -->

    <!-- ======================
      Blog Single
    ========================= -->
    <section id="blogSingleCentered" class="blog blog-single pb-60">
      <div class="container">
        <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-4">
            <aside class="sidebar mb-30">
              
              <div class="widget widget-categories">
                <h5 class="widget__title">categories</h5>
                <div class="widget-content">
                  <ul class="list-unstyled">
                    <?php if($categorys->count() > 0): ?>
                      <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><a href="<?php echo e(route('blogs.index', ['category' => $category->slug])); ?>"><?php echo e($category->name); ?></a></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </ul>
                </div><!-- /.widget-content -->
              </div><!-- /.widget-categories -->
              <div class="widget widget-posts">
                <h5 class="widget__title">Recent Posts</h5>
                <div class="widget__content">
                  <?php if($posts->count() > 0): ?>
                  <!-- post item #1 -->
                  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="widget-post-item">
                    <div class="widget__post-img">
                      <a href="<?php echo e(route('blogs.show', $item->slug)); ?>"><img src="<?php echo postImage($item->image); ?>" alt="<?php echo e($item->title); ?>"></a>
                    </div><!-- /.widget-post-img -->
                    <div class="widget__post-content">
                      <div class="d-flex flex-wrap align-items-center">
                        
                        <span class="widget__post-date"><?php echo $item->created_at->format('M d, Y'); ?></span>
                      </div>
                      <h6 class="widget__post-title"><a href="<?php echo e(route('blogs.show', $item->slug)); ?>"><?php echo e($item->title); ?></a></h6>
                    </div><!-- /.widget-post-content -->
                  </div><!-- /.widget-post-item -->
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php endif; ?>

                </div><!-- /.widget-content -->
              </div><!-- /.widget-posts -->
            </aside><!-- /.sidebar -->
          </div><!-- /.col-lg-4 -->
          <div class="col-sm-12 col-md-12 col-lg-8">
            <div class="blog-item">
              <div class="blog__img">
                <a href="#">
                  <img src="<?php echo postImage($post->image); ?>" alt="<?php echo $post->title; ?>">
                </a>
              </div><!-- /.entry-img -->
              <div class="blog__content">
                <h4 class="blog__title"><a href="#"><?php echo $post->title; ?></a></h4>
                <div class="blog__meta justify-content-center">
                  <span class="blog__meta-author pr-20">By: <span>Admin</span></span>
                  <span class="blog__meta-date"><?php echo $post->created_at->format('M d, Y'); ?></span>
                </div><!-- /.blog-meta -->
                <div class="divider__line divider__theme divider__center"></div>
                <br>
                <?php if(!empty($post->document) && $post->document != '[]'): ?>
                  <a href="<?php echo e(route('downloadFile',$post->id)); ?>" class="btn btn-primary">Download File</a>
                <?php endif; ?>
                <br>
                <div class="blog__desc">
                  <p><?php echo $post->body; ?></p>
                </div><!-- /.blog-desc -->
              </div><!-- /.entry-content -->
            </div><!-- /.blog-item -->
            

            <hr>
            <div class="blog-comments mb-50">
              <h5 class="blog__widget-title"><?php echo e($comments->count()); ?> comments</h5>
              <ul class="comments-list">


                <?php if($comments->count() > 0): ?>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="comment__item">
                  <div class="comment__content">
                    <h6 class="comment__author"><?php echo e($comment->name); ?></h6>
                    <span class="comment__date"><?php echo e($comment->created_at->format('M d, Y')); ?></span>
                    <p class="comment__desc"><?php echo e($comment->body); ?></p>
                    
                  </div>

                  

                </li><!-- /.comment -->
                
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>    

              </ul><!-- /.comments-list -->
            </div><!-- /.blog-comments -->
            <div class="blog-widget blog-comments-form">
              <h5 class="blog__widget-title">Leave A Reply</h5>
              <form action="<?php echo e(route('comment',$post->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo app('captcha')->render(); ?>
                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="row">
                  <div class="col-sm-12 col-md-6 col-lg-6">
                    <div class="form-group">
                      <input name="name" type="text" class="form-control" placeholder="Name:">
                    </div><!-- /.form-group -->
                  </div><!-- /.col-lg-6 -->
                  <div class="col-sm-12 col-md-6 col-lg-6">
                    <div class="form-group">
                      <input name="email" type="email" class="form-control" placeholder="Email:">
                    </div><!-- /.form-group -->
                  </div><!-- /.col-lg-6 -->
                  <div class="col-sm-12 col-md-12 col-lg-12">
                    <div class="form-group">
                      <textarea name="body" class="form-control" placeholder="Comment"></textarea>
                    </div><!-- /.form-group -->
                  </div><!-- /.col-lg-12 -->
                  <div class="col-sm-12 col-md-12 col-lg-12">
                    <button type="submit" class="btn btn__secondary btn__block">Submit Comment</button>
                  </div><!-- /.col-lg-12 -->
                </div><!-- /.row -->
              </form>
            </div><!-- /.blog-comments-form -->
          </div><!-- /.col-lg-8 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.blog Single -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

  <script src="<?php echo e(asset('assets/js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\logistics\resources\views/blog-single.blade.php ENDPATH**/ ?>