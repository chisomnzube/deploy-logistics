<?php $__env->startSection('head'); ?>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <meta name="description" content="Logisti ">
  <link href="assets/images/favicon/favicon.png" rel="icon">
  <title>Local & International Procurement  - <?php echo e(config('app.name')); ?></title>
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Roboto:400,700%7cWork+Sans:400,600,700&display=swap">
  <link rel="stylesheet" href="assets/css/libraries.css" />
  <link rel="stylesheet" href="assets/css/style.css" />
  <script src="https://kit.fontawesome.com/dfbe4c7cae.js" crossorigin="anonymous"></script>
</head>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <!-- ========================
       page title 
    =========================== -->
    <section id="page-title" class="page-title bg-overlay bg-parallax">
      <div class="bg-img"><img src="<?php echo e(asset('img/banner4.jpg')); ?>" alt="Local & International Procurement  - <?php echo e(config('app.name')); ?>"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('landingpage')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Local & International Procurement</li>
              </ol>
            </nav>
            <h1 class="pagetitle__heading">Local & International Procurement</h1>
          </div><!-- /.col-lg-12 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.page-title -->

    <!-- ======================
      case studies Single
    ========================= -->
    <section id="caseStudiesSingle" class="case-studies-single">
      <div class="container">
        <div class="row">
         
          <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="case-single-item">
              <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                  <div class="text__block mb-40">
                    <h1 class="text__block-title">Local & International Procurement</h1>
                    <p class="text__block-desc">We source and procure items both locally and globally based on our wide coverage of the local market.  
                    </p>
                    <div class="row">
                      <div class="col-md-6 col-lg-6 col-sm-12">
                    <h5 class="text__block-title">Local Sourcing &  Procurement</h5>
                    <p class="text__block-desc">We have built vast network of resources with various service providers, dealers and vendors in Nigeria for local supplies. <br>
                    We have vast network to facilitate sourcing and procurement of goods, equipment and other project specific items all over the Globe. 
  
                    </p>

                  </div>
                    <div class="col-md-6 col-lg-6 col-sm-12">
                    <h5 class="text__block-title">International Sourcing &  Procurement</h5>
                    <p class="text__block-desc">We have access to vast buying houses that provide the necessary support and service needed by the client and in line with details and specified requirements. This operations is complimented by our Local and international freight forwarding and shipping operations to provide a seamless service delivery in line with international best practice. <br>
                    We source and procure items both locally and globally based on our wide coverage of the local market. <br>
                    We have built a relationships with various  OEM, Dealers and Buying Houses and have access to wide range of products and services. <br>
                    We can offer OEM & Product Representation in the following Industries:
                    </p>
                    <ul class="list-group" >
                      <li ><i class="fas fa-angle-double-right"></i>Oil & Gas </li>
                      <li ><i class="fas fa-angle-double-right"></i>Power Industry </li>
                      <li ><i class="fas fa-angle-double-right"></i>Renewable Energy Industry </li>
                      <li ><i class="fas fa-angle-double-right"></i>Heavy Equipment </li>
                      <li ><i class="fas fa-angle-double-right"></i>Allied & Petrochemical Company</li>
                      <li ><i class="fas fa-angle-double-right"></i>Other specified requirements that can be sourced</li>
                    </ul>
                  </div>
                </div>

                  </div><!-- /.text-block -->
                  

            </div><!-- /.case-single-item -->
          </div><!-- /.col-lg-8 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.case studies Single -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>   

  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/plugins.js"></script>
  <script src="assets/js/main.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\logistics\resources\views/procurement.blade.php ENDPATH**/ ?>