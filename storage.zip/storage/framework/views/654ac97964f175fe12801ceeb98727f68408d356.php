<?php $__env->startSection('head'); ?>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <meta name="description" content="Logisti ">
  <link href="assets/images/favicon/favicon.png" rel="icon">
  <title>Contact Us - <?php echo e(config('app.name')); ?> </title>
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Roboto:400,700%7cWork+Sans:400,600,700&display=swap">
  <link rel="stylesheet" href="assets/css/libraries.css" />
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- ========================
       page title 
    =========================== -->
    <section id="page-title" class="page-title bg-overlay bg-parallax">
      <div class="bg-img"><img src="<?php echo e(asset('images/consultancy1.jpg')); ?>" alt="Contact Us - <?php echo e(config('app.name')); ?>"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('landingpage')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
              </ol>
            </nav>
            <h1 class="pagetitle__heading">Contact Us</h1>
          </div><!-- /.col-lg-12 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.page-title -->

    <!-- ==========================
        contact 1
    =========================== -->
    <section id="contact1" class="contact text-center">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
            <div class="heading text-center mb-50">
              <span class="heading__subtitle">Get In Touch</span>
              <h2 class="heading__title">Contact Us</h2>
              <div class="divider__line divider__theme divider__center mb-0"></div>
              <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <p class="heading__desc">We understand the importance of approaching each work integrally and believe in
                the power of simple and easy communication.</p>
            </div><!-- /.heading -->
          </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-8 offset-lg-2">
            <form action="<?php echo e(route('store.contact')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php echo app('captcha')->render(); ?>
              <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                  <div class="form-group"><input name="name" type="text" class="form-control" placeholder="Name"></div>
                </div><!-- /.col-lg-6 -->
              </div><!-- /.row -->
              <div class="row">
                <div class="col-sm-6 col-md-6 col-lg-6">
                  <div class="form-group"><input name="phone" type="text" class="form-control" placeholder="Phone"></div>
                </div><!-- /.col-lg-6 -->
                <div class="col-sm-6 col-md-6 col-lg-6">
                  <div class="form-group"><input name="email" type="text" class="form-control" placeholder="Email"></div>
                </div><!-- /.col-lg-6 -->
              </div><!-- /.row -->
              <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                  <div class="form-group">
                    <textarea name="body" class="form-control" placeholder="Request Details"></textarea>
                  </div>
                </div><!-- /.col-lg-12 -->
              </div><!-- /.row -->
              <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">Any Document:
                  <div class="form-group"><input name="image" type="file" class="form-control" placeholder="File"></div>
                </div><!-- /.col-lg-6 -->
              </div><!-- /.row -->
              <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                  <button type="submit" class="btn btn__secondary btn__hover3">Submit Request</button>
                </div><!-- /.col-lg-12 -->
              </div><!-- /.row -->
            </form>
          </div><!-- /.col-lg-8 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.contact 1 -->



    <!-- ==========================
       Contact panels
    ============================ -->
    <section id="contactPanels" class="contact-panels text-center pb-70">
      <div class="container">
        <div class="row">
          <!-- Contact panel #1 -->
          <div class="col-sm-12 col-md-12 col-lg-4">
            <div class="contact-panel">
              <div class="contact__panel-header">
                <h4 class="contact__panel-title">London Office</h4>
              </div>
              <ul class="contact__list list-unstyled">
                <li>002 010123456789</li>
                <li>Email: Logisti@7oroof.com</li>
                <li>Address: 2307 Beverley Rd Brooklyn, NY</li>
                <li>Hours: Mon-Fri: 8am – 7pm</li>
              </ul>
              <a href="#" class="btn btn__primary btn__hover3">Read More</a>
            </div><!-- /.contact-panel -->
          </div><!-- /.col-lg-4 -->
          <!-- Contact panel #2 -->
          <div class="col-sm-12 col-md-12 col-lg-4">
            <div class="contact-panel">
              <div class="contact__panel-header">
                <h4 class="contact__panel-title">Berlin Office</h4>
              </div>
              <ul class="contact__list list-unstyled">
                <li>002 010123456789</li>
                <li>Email: Logisti@7oroof.com</li>
                <li>Address: 2307 Beverley Rd Brooklyn, NY</li>
                <li>Hours: Mon-Fri: 8am – 7pm</li>
              </ul>
              <a href="#" class="btn btn__primary btn__hover3">Read More</a>
            </div><!-- /.contact-panel -->
          </div><!-- /.col-lg-4 -->
          <!-- Contact panel #3 -->
          <div class="col-sm-12 col-md-12 col-lg-4">
            <div class="contact-panel">
              <div class="contact__panel-header">
                <h4 class="contact__panel-title">Manchester Office</h4>
              </div>
              <ul class="contact__list list-unstyled">
                <li>002 010123456789</li>
                <li>Email: Logisti@7oroof.com</li>
                <li>Address: 2307 Beverley Rd Brooklyn, NY</li>
                <li>Hours: Mon-Fri: 8am – 7pm</li>
              </ul>
              <a href="#" class="btn btn__primary btn__hover3">Read More</a>
            </div><!-- /.contact-panel -->
          </div><!-- /.col-lg-4 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /. Contact panels -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>   

  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/plugins.js"></script>
  <script src="assets/js/main.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\logistics\resources\views/contact.blade.php ENDPATH**/ ?>